from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__, template_folder="new_template")

# Load model 
model = pickle.load(open("pklmodel/titanic_model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

@app.route("/")
def home():
    return render_template("web_file.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        features = [
            int(request.form["pclass"]),
            int(request.form["sex"]),
            float(request.form["age"]),
            int(request.form["sibsp"]),
            int(request.form["parch"]),
            float(request.form["fare"]),
            int(request.form["embarked"]),
            int(request.form["pclass_new"]),  
            int(request.form["adult_male"]),
            int(request.form["alone"]),
        ]

        final_input = scaler.transform([features])
        pred = model.predict(final_input)
        prediction = f"Prediction class is: {pred[0]}"
        return render_template("web_file.html", prediction=prediction)

    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)
